=== musescircle ===
Contributors: displaycoffee
Requires at least: 4.0
Tested up to: WordPress 4.5
Version: 3.0
License: GNU General Public License
License URI: https://www.gnu.org/licenses/gpl.html
Tags: custom base wordpress theme

== Description ==

A theme for musescircle.com

== Credits/Copyright ==
Theme created by displaycoffee. Copyright 2016 musescircle.com.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.

This theme uses:
* normalize

== Changelog ==

= 3.0 =
Major updates including changing HTML schema markup to json-ld markup.

= 2.0 =
Fixed schema.org markup for blog posts and added default images for markup to be validates. Moved main-title header above content section.

= 1.0 =
Created theme setup.