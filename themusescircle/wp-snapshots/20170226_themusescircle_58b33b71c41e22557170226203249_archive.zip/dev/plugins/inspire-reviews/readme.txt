=== Plugin Name ===
Contributors: kailala
Tags: reviews, movies, tv, books
Requires at least: 4.0
Tested up to: 4.5
Stable tag: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Used for reviewing various types of media such as books, movies, and tv.

== Description ==

Used for reviewing various types of media such as books, movies, and tv.

== Installation ==

In WordPress, do the following:

1. Plugins > Add New.
2. Click on "Upload Plugin" button.
3. Activate the plugin.

== Changelog ==

= 9.0 =
Major updates including changing HTML schema markup to json-ld markup.

= 8.5 =
Add new book buy links, author amazon profile link, and bold and italic shortcodes. Enabled those shortcodes for display on the synopsis.

= 8.0 =
Add template for 'All Reviews' page.

= 7.0 =
Add recent reviews shortcode.

= 6.0 =
Add author block shortcode and update files to use this.

= 5.5 =
Added archive pages for movies and tv shows.

= 5.0 =
Added single templates for movies, tv, and books. Added archive pages for movies.

= 4.0 =
Created a readme.txt file.